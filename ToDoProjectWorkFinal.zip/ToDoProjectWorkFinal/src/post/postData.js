import React from "react"
import { Link } from "react-router-dom"
import postDetails from "./postDetails";
import "../App.css"

class Post extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            userDetails: [],
            noOfCom: 0
        }
    }


    componentDidMount() {
        const user = this.props.location.state.user;
        const url = "https://jsonplaceholder.typicode.com/posts?userId=" + user.id;
        fetch(url)
            .then(response => response.json())
            .then(data => {
                this.setState({
                    userDetails: data
                });
            })
    }
    

    render() {


        const UserPosts = this.state.userDetails.map(post => {
            return <tr key={post.id}>
                <td>{post.title}{post.body}</td>
                <td><Link to={
                    {
                        pathname: '/post/postDetails',
                        state: { post: { id: post.id }, fromPath: '/postData' }
                    }
                }>View Details</Link></td>


            </tr >

        });

        const { fromPath } = this.props.location.state;
        this.state.noOfCom = this.state.userDetails.length;





        return (
            <div className="container" >
                <div className="card">
                    <h3 className="h3">Number of comments:{this.state.noOfCom}</h3>
                    <div><h3 className="banner"> Post</h3></div>
                    <table id="td1"  className="table table-bordered ">
                        <tbody>
                            {UserPosts}
                        </tbody>
                    </table>

                </div>
                <div className="card-footer">
                    <Link className="btn btn-primary" to={fromPath}>Go back</Link>
                </div>

            </div>
        )
    }
}
export default Post;