import React from "react";
 import { Link } from 'react-router-dom'

class userDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      todoDetails: [],
      todoNo: 0,
      toDoList: [],
      completedFlag: false
    };
  }

  componentDidMount() {
    const user = this.props.location.state.user;
    const url = "https://jsonplaceholder.typicode.com/todos?userId=" + user.id;
    fetch(url)
      .then(response => response.json())
      .then(data => {

        this.setState({
          todoDetails: data,
          toDoList: this.getToDoList(data, this.state.completedFlag)
        });
      });
  }

  handleCheck = (evt) => {
    
    this.setState({
        completedFlag: evt.target.checked,
        toDoList: this.getToDoList(this.state.todoDetails, evt.target.checked)
    });
  }

  getToDoList = (fetchedData = this.state.todoDetails,completedFlag) => {
    const flagBasedTodoList = fetchedData.filter(item => {
    if(completedFlag === 'false'){
        return item

    }else{
        return item.completed === completedFlag

    }
    });

    if(completedFlag === 'false'){

        fetchedData=this.state.todoDetails
    }
    
    const flagBasedTodoListHTML = flagBasedTodoList.map( item => {
        return <tr key={item.id}><td>{item.title}</td></tr>
    })
    return flagBasedTodoListHTML;
  };

  render() 
  
  {const { fromPath } = this.props.location.state;
    return (
      <div className="container">
        <input type="checkbox" onChange={this.handleCheck} />
        View all
        <div className="card">
          <div><h3 className="banner">Todo's</h3></div>
          <div className="card-body">
            <table className="table table-bordered">
              <tbody>{this.state.toDoList}</tbody>
            </table>
          </div>
          <div className="card-footer">
                        <Link className="btn btn-primary" to={fromPath}>Go back</Link>
                    </div>
        </div>
      </div>
    );
  }
}
export default userDetails;