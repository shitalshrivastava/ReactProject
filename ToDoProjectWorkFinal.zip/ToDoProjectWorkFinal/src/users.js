import React from "react";
import { Link } from 'react-router-dom'
import user from "./user"
import Post from "./post/postData"
import  "./App.css"


class Users extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      users: [],
      noOfUsers: 0
    }
  }

  componentDidMount() {
    const url = 'https://jsonplaceholder.typicode.com/users';
    fetch(url)
      .then(response => response.json())
      .then(data => {
        this.setState({
          users: data
        })
      });
  }

  render() {
    

    this.state.noOfUsers = this.state.users.length;

    const UserRows = this.state.users.map(user => {
      return <tr key={user.id}>
        <td>{user.name}</td>
        <td>{user.username}</td>
        <td>{user.email}</td>
        <td><strong>Street:</strong>{user.address.street},
        <strong>City:</strong>{user.address.city},
       <strong> Zip:</strong>{user.address.zipcode}</td>

        <td><Link to={
          {
            pathname: '/user',
            state: { user: { id: user.id }, fromPath: '/users' }
          }
        }>View</Link></td>

        <td><Link to={
          {
            pathname: '/post/postData',
            state: { user: { id: user.id }, fromPath: '/users' }
          }
        }>View</Link></td>
      </tr>
    });


    return (
      <div>
        <h1 className="banner">Daily planner</h1>
        <h3 className="h3">No of users:{this.state.noOfUsers} </h3>
        <table className="table table-bordered">

          <thead>
            <tr>
              <th>Name</th>
              <th>Username</th>
              <th>Email</th>
              <th>Address</th>
              <th>Todo's</th>
              <th>Posts</th>
            </tr>
          </thead>
          <tbody>
            {UserRows}
          </tbody>
        </table>
      </div>
    )
  }

}
export default Users;